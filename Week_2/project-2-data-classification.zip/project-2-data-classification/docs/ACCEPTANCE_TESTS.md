# Acceptance Tests — Project 2: Data Classification Using KNN

## Functional Requirements Testing

### Requirement 1: Dataset Loading
- [ ] Iris dataset loads successfully (150 samples, 4 features)
- [ ] Dataset has exactly 3 classes
- [ ] Class names are ["setosa", "versicolor", "virginica"]
- [ ] No data corruption or loading errors

### Requirement 2: Data Inspection
- [ ] Dataset shape correctly reported as (150, 4)
- [ ] Feature count = 4
- [ ] Sample count = 150
- [ ] Class count = 3
- [ ] Feature names are correctly identified

### Requirement 3: Train-Test Split
- [ ] Training set contains 120 samples (80%)
- [ ] Test set contains 30 samples (20%)
- [ ] Split is stratified (all 3 classes in both sets)
- [ ] Random state = 42 for reproducibility
- [ ] Split is consistent across multiple runs with same random_state

### Requirement 4: Feature Scaling
- [ ] StandardScaler is applied
- [ ] Scaler fitted on training data only
- [ ] Test data transformed using training statistics
- [ ] Scaled features have mean ≈ 0 and std ≈ 1
- [ ] Feature shapes preserved after scaling

### Requirement 5: Model Training
- [ ] KNeighborsClassifier instantiated with K=5
- [ ] Model trained on scaled training data
- [ ] Training completes without errors
- [ ] Model stores training data correctly

### Requirement 6: Prediction
- [ ] Model generates predictions for all 30 test samples
- [ ] Predictions are class labels (0, 1, or 2)
- [ ] No NaN or invalid predictions
- [ ] Prediction shape matches test set shape

### Requirement 7: Evaluation Metrics
- [ ] Accuracy calculated correctly (0 ≤ acc ≤ 1)
- [ ] Weighted F1 score calculated (0 ≤ f1 ≤ 1)
- [ ] Confusion matrix generated (3×3 shape)
- [ ] Classification report generated (contains precision, recall, F1)

### Requirement 8: Confusion Matrix Visualization
- [ ] Confusion matrix saved as PNG image
- [ ] File saved to outputs/confusion_matrix.png
- [ ] Heatmap includes annotations (counts)
- [ ] Heatmap includes labels (class names)
- [ ] File is readable and valid PNG

## Code Quality Testing

### Code Organization
- [ ] Main code in src/classification.py
- [ ] Tests in tests/test_classification.py
- [ ] Docs in docs/ directory
- [ ] All files present and readable

### Function Structure
- [ ] `load_and_inspect_data()` function exists
- [ ] `split_data()` function exists
- [ ] `scale_features()` function exists
- [ ] `train_model()` function exists
- [ ] `evaluate_model()` function exists
- [ ] `plot_confusion_matrix()` function exists
- [ ] `main()` function exists

### Function Correctness
- [ ] load_and_inspect_data() returns (X, y, target_names)
- [ ] split_data() returns (X_train, X_test, y_train, y_test)
- [ ] scale_features() returns (X_train_scaled, X_test_scaled)
- [ ] train_model() returns KNeighborsClassifier instance
- [ ] evaluate_model() returns dict with results

### Code Quality Checks
- [ ] No hardcoded evaluation results
- [ ] No data leakage (scaler fitted on train only)
- [ ] Random states set consistently
- [ ] No fabricated metrics or outputs
- [ ] Comments and docstrings present
- [ ] PEP 8 style generally followed

## Testing Requirements

### Unit Tests Exist For:
- [ ] Dataset loading and shape
- [ ] Dataset classes and target names
- [ ] Train-test split ratios
- [ ] Split reproducibility
- [ ] Split stratification
- [ ] Feature scaling application
- [ ] Scaling shape preservation
- [ ] Model type (KNeighborsClassifier)
- [ ] Model K value (5)
- [ ] Prediction count
- [ ] Prediction labels validity
- [ ] Accuracy range (0-1)
- [ ] F1 score range (0-1)
- [ ] Confusion matrix shape (3×3)
- [ ] Classification report exists

### Test Execution
- [ ] pytest runs without errors
- [ ] All tests pass
- [ ] At least 15 tests defined
- [ ] No test failures on clean install

### Test Coverage
- [ ] Data loading tested
- [ ] Data splitting tested
- [ ] Feature scaling tested
- [ ] Model training tested
- [ ] Prediction tested
- [ ] Evaluation tested

## Integration Testing

### End-to-End Pipeline
- [ ] Script runs from start to finish without errors
- [ ] All pipeline stages execute successfully
- [ ] Outputs printed to console
- [ ] Confusion matrix file generated
- [ ] No exceptions or crashes

### Reproducibility
- [ ] Same results on multiple runs with same random_state
- [ ] Confusion matrix identical across runs
- [ ] Metrics identical across runs
- [ ] Different random_states produce different results

## Documentation Requirements

### README.md
- [ ] Project title present
- [ ] Objective clearly stated
- [ ] Dataset description included
- [ ] Feature/class descriptions complete
- [ ] Workflow described step-by-step
- [ ] Algorithm explanation included
- [ ] Installation instructions clear
- [ ] How to run section present
- [ ] How to run tests section present
- [ ] Evaluation metrics explained
- [ ] Expected output described
- [ ] Project structure documented
- [ ] Limitations listed
- [ ] Learning outcomes included

### Report Outline (REPORT_OUTLINE.md)
- [ ] Sections 1-12 structured
- [ ] Placeholders for results marked [TO BE FILLED]
- [ ] Report executable after filling in results
- [ ] Includes confusion matrix section
- [ ] Includes error analysis section
- [ ] Includes recommendations

### Project Specification (docs/PROJECT_SPEC.md)
- [ ] Copied from uploaded spec (if provided)
- [ ] Or placeholder exists

## Dependency Management

### requirements.txt
- [ ] File exists and is readable
- [ ] scikit-learn listed
- [ ] numpy listed
- [ ] matplotlib listed
- [ ] seaborn listed
- [ ] pytest listed
- [ ] All versions specified
- [ ] `pip install -r requirements.txt` works

### Environment
- [ ] Clean Python 3.7+ environment can run project
- [ ] All imports work
- [ ] No missing dependencies
- [ ] No version conflicts

## File Structure Verification

### Directory Structure
```
project-2-data-classification/
├── README.md                          ✓
├── requirements.txt                   ✓
├── .gitignore                         ✓
├── src/
│   └── classification.py              ✓
├── tests/
│   └── test_classification.py         ✓
├── docs/
│   ├── PROJECT_SPEC.md                ✓
│   ├── REPORT_OUTLINE.md              ✓
│   └── ACCEPTANCE_TESTS.md            ✓
└── outputs/
    └── .gitkeep                       ✓
```

- [ ] All directories exist
- [ ] All files present
- [ ] Files are readable
- [ ] outputs/ directory exists (for generated files)

## Performance & Constraints

### Performance Requirements
- [ ] Script completes in < 5 seconds
- [ ] Pytest suite completes in < 10 seconds
- [ ] No memory leaks
- [ ] Handles dataset efficiently

### Constraint Compliance
- [ ] Uses Iris dataset only (not replaced)
- [ ] KNN K=5 (not changed)
- [ ] 80-20 train-test split maintained
- [ ] Stratified split used
- [ ] StandardScaler applied
- [ ] Scaler fit on training data only
- [ ] All required metrics calculated
- [ ] Confusion matrix file generated
- [ ] Pytest automated tests included
- [ ] Professional README present
- [ ] requirements.txt and .gitignore present

## Acceptance Criteria Summary

### Project Passes If:
- [x] All mandatory requirements implemented
- [x] Code runs without errors
- [x] All tests pass
- [x] Generated outputs correct
- [x] Documentation complete
- [x] No data leakage
- [x] No fabricated results
- [x] Clean repository structure
- [x] GitHub-ready (includes README, gitignore, tests)
- [x] Reproducible (fixed random states)

### Sign-Off
- [ ] Code review passed
- [ ] Tests verified
- [ ] Outputs validated
- [ ] Documentation reviewed
- [ ] Project ready for GitHub

---

**Checklist Version**: 1.0  
**Last Updated**: [DATE]  
**Status**: Ready for Testing
