"""
Data Classification using K-Nearest Neighbors (KNN) on Iris Dataset
"""

import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import (
    accuracy_score,
    f1_score,
    confusion_matrix,
    classification_report,
)


def load_and_inspect_data():
    """Load Iris dataset and perform basic inspection."""
    iris = load_iris()
    X = iris.data
    y = iris.target

    print("=" * 60)
    print("DATASET INSPECTION")
    print("=" * 60)
    print(f"Dataset shape: {X.shape}")
    print(f"Number of features: {X.shape[1]}")
    print(f"Number of samples: {X.shape[0]}")
    print(f"Number of classes: {len(np.unique(y))}")
    print(f"Class labels: {np.unique(y)}")
    print(f"Class names: {iris.target_names}")
    print(f"Feature names: {iris.feature_names}")
    print()

    return X, y, iris.target_names


def split_data(X, y, test_size=0.2, random_state=42):
    """Split data into training and testing sets using stratified split."""
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=test_size, random_state=random_state, stratify=y
    )

    print("=" * 60)
    print("TRAIN-TEST SPLIT")
    print("=" * 60)
    print(f"Training set size: {X_train.shape[0]} samples ({100 * (1 - test_size):.0f}%)")
    print(f"Testing set size: {X_test.shape[0]} samples ({100 * test_size:.0f}%)")
    print()

    return X_train, X_test, y_train, y_test


def scale_features(X_train, X_test):
    """Scale features using StandardScaler (fit only on training data)."""
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_test_scaled = scaler.transform(X_test)

    print("=" * 60)
    print("FEATURE SCALING")
    print("=" * 60)
    print("StandardScaler applied (fit on training data only)")
    print()

    return X_train_scaled, X_test_scaled


def train_model(X_train, y_train, n_neighbors=5):
    """Train K-Nearest Neighbors classifier."""
    model = KNeighborsClassifier(n_neighbors=n_neighbors)
    model.fit(X_train, y_train)

    print("=" * 60)
    print("MODEL TRAINING")
    print("=" * 60)
    print(f"Algorithm: K-Nearest Neighbors (KNN)")
    print(f"K value: {n_neighbors}")
    print(f"Training samples: {X_train.shape[0]}")
    print()

    return model


def evaluate_model(model, X_test, y_test, target_names):
    """Evaluate model performance on test set."""
    y_pred = model.predict(X_test)

    accuracy = accuracy_score(y_test, y_pred)
    f1_weighted = f1_score(y_test, y_pred, average="weighted")
    conf_matrix = confusion_matrix(y_test, y_pred)
    class_report = classification_report(y_test, y_pred, target_names=target_names)

    print("=" * 60)
    print("MODEL EVALUATION")
    print("=" * 60)
    print(f"Accuracy: {accuracy:.4f}")
    print(f"Weighted F1 Score: {f1_weighted:.4f}")
    print()

    print("Confusion Matrix:")
    print(conf_matrix)
    print()

    print("Classification Report:")
    print(class_report)
    print()

    return {
        "y_pred": y_pred,
        "accuracy": accuracy,
        "f1_weighted": f1_weighted,
        "confusion_matrix": conf_matrix,
        "classification_report": class_report,
    }


def plot_confusion_matrix(conf_matrix, target_names, output_path="outputs/confusion_matrix.png"):
    """Plot and save confusion matrix heatmap."""
    plt.figure(figsize=(8, 6))
    sns.heatmap(
        conf_matrix,
        annot=True,
        fmt="d",
        cmap="Blues",
        xticklabels=target_names,
        yticklabels=target_names,
        cbar_kws={"label": "Count"},
    )
    plt.title("Confusion Matrix - Iris Dataset (KNN, K=5)")
    plt.ylabel("True Label")
    plt.xlabel("Predicted Label")
    plt.tight_layout()
    plt.savefig(output_path, dpi=300, bbox_inches="tight")
    print(f"Confusion matrix saved to: {output_path}")
    plt.close()


def main():
    """Main pipeline."""
    # Load and inspect
    X, y, target_names = load_and_inspect_data()

    # Split
    X_train, X_test, y_train, y_test = split_data(X, y)

    # Scale
    X_train_scaled, X_test_scaled = scale_features(X_train, X_test)

    # Train
    model = train_model(X_train_scaled, y_train)

    # Evaluate
    results = evaluate_model(model, X_test_scaled, y_test, target_names)

    # Plot confusion matrix
    plot_confusion_matrix(results["confusion_matrix"], target_names)

    return {
        "model": model,
        "scaler": StandardScaler(),
        "results": results,
        "X_train": X_train,
        "X_test": X_test,
        "y_train": y_train,
        "y_test": y_test,
        "X_train_scaled": X_train_scaled,
        "X_test_scaled": X_test_scaled,
    }


if __name__ == "__main__":
    main()
